// Copyright (c) Facebook, Inc. and its affiliates.
use anyhow::bail;
use anyhow::{Context, Result};
use glob::glob;
use log::{debug, trace, warn};
use proc_mounts::{MountInfo, MountList, SwapIter};
use scan_fmt::scan_fmt;
use std::ffi::{OsStr, OsString};
use std::fs;
use std::io::Read;
use std::os::linux::fs::MetadataExt;
use std::os::unix::fs::FileTypeExt;
use std::path::{Path, PathBuf};
use std::process::Command;

lazy_static::lazy_static! {
    static ref MOUNT_LIST: Result<MountList> = Ok(MountList::new()?);
    static ref FINDMNT_BIN: String = super::find_bin("findmnt", Option::<&str>::None)
        .expect("Failed to find findmnt bin")
        .to_str()
        .unwrap()
        .to_owned();
}

/// Given a path, find out the containing mountpoint.
pub fn path_to_mountpoint<P: AsRef<Path>>(path_in: P) -> Result<MountInfo> {
    let path = path_in.as_ref();
    let mut abs_path = fs::canonicalize(&path)?;
    let mounts = match MOUNT_LIST.as_ref() {
        Ok(v) => v,
        Err(e) => bail!("Failed to list mount points ({:?})", &e),
    };

    loop {
        if let Some(mi) = mounts.get_mount_by_dest(&abs_path) {
            debug!("found mount point {:?} for {:?}", &mi.dest, &path);
            return Ok(mi.clone());
        }
        if !abs_path.pop() {
            bail!("Failed to find mount point for {:?}", path);
        }
    }
}

fn match_devnr<P: AsRef<Path>>(path_in: P, devnr: u64) -> bool {
    let path = path_in.as_ref();
    let mut buf = String::new();
    if let Err(err) = fs::File::open(&path).and_then(|mut f| f.read_to_string(&mut buf)) {
        warn!("Failed to open {:?} ({:?})", &path, &err);
        return false;
    }

    trace!("matching {:?} content '{}'", &path, buf.trim());
    let (maj, min) = match scan_fmt!(&buf, "{d}:{d}", u32, u32) {
        Ok(v) => v,
        Err(e) => {
            warn!("Failed to parse '{}' ({:?})", buf.trim(), &e);
            return false;
        }
    };

    if devnr == libc::makedev(maj, min) {
        trace!("matched {:?}", &path);
        return true;
    }
    return false;
}

/// Given a device number, find the kernel device name.
fn devnr_to_devname(devnr: u64) -> Result<OsString> {
    let blk_dir = Path::new("/sys/block");
    let blk_iter = blk_dir.read_dir()?;

    for blk_path in blk_iter.filter_map(|r| r.ok()).map(|e| e.path()) {
        let mut dev_path = PathBuf::from(&blk_path);

        dev_path.push("dev");
        if match_devnr(&dev_path, devnr) {
            dev_path.pop();
            return Ok(dev_path.file_name().unwrap().into());
        }
        dev_path.pop();

        let pattern = format!(
            "{}/{}*/dev",
            dev_path.to_str().unwrap().to_string(),
            dev_path.file_name().unwrap().to_str().unwrap()
        );
        for part in glob(&pattern).unwrap().filter_map(|x| x.ok()) {
            if match_devnr(&part, devnr) {
                return Ok(dev_path.file_name().unwrap().into());
            }
        }
    }
    bail!("No matching dev for 0x{:x}", devnr);
}

/// Given a device name, find the device number.
pub fn devname_to_devnr<D: AsRef<OsStr>>(name_in: D) -> Result<(u32, u32)> {
    let mut path = PathBuf::from("/dev");
    path.push(name_in.as_ref());
    let rdev = fs::metadata(path)?.st_rdev();
    Ok(({ libc::major(rdev) }, { libc::minor(rdev) }))
}

// Never pass findmnt's display SOURCE (e.g. /dev/nvme0n1p6[/@]) to stat.
// --nofsroot returns the device only; JSON preserves whitespace/escapes and the
// explicit --target disambiguates paths from source selectors.
const FINDMNT_SOURCE_ARGS: [&str; 7] = [
    "--json", "--first-only", "--evaluate", "--nofsroot", "--output", "SOURCE", "--target",
];

fn findmnt_source(output: &[u8]) -> Result<PathBuf> {
    let value: serde_json::Value = serde_json::from_slice(output)
        .context("parse findmnt SOURCE JSON")?;
    let filesystems = value.get("filesystems").and_then(|v| v.as_array())
        .context("findmnt did not return a filesystems array")?;
    if filesystems.len() != 1 {
        bail!("findmnt must return exactly one containing filesystem, got {}", filesystems.len());
    }
    let source = filesystems[0].get("source").and_then(|v| v.as_str())
        .context("findmnt did not return a SOURCE string")?;
    let path = PathBuf::from(source);
    if !path.is_absolute() || !path.starts_with("/dev") || source.as_bytes().contains(&0) {
        bail!("filesystem SOURCE is not a local device path: {:?}", source);
    }
    Ok(path)
}

/// Given an existing path, find the underlying whole-device queue.
/// Btrfs subvolume roots must not be interpreted as part of the device filename.
pub fn path_to_devname<P: AsRef<Path>>(path: P) -> Result<OsString> {
    let target = fs::canonicalize(path.as_ref())
        .with_context(|| format!("resolve filesystem path {:?}", path.as_ref()))?;
    let output = Command::new(&*FINDMNT_BIN)
        .args(&FINDMNT_SOURCE_ARGS)
        .arg(&target)
        .output().context("execute findmnt for backing device")?;
    if !output.status.success() {
        bail!("findmnt on {:?} failed with {:?}", target, output);
    }
    let source = findmnt_source(&output.stdout)?;
    trace!("path_to_devname path={:?} source={:?}", target, source);
    let metadata = fs::metadata(&source)
        .with_context(|| format!("stat resolved filesystem device {:?}", source))?;
    if !metadata.file_type().is_block_device() {
        bail!("filesystem source is not a block device: {:?}", source);
    }
    devnr_to_devname(metadata.st_rdev())
}

fn read_model(dev_path: &Path) -> Result<String> {
    let mut path = PathBuf::from(dev_path);
    path.push("device");
    path.push("model");

    let mut model = String::new();
    let mut f = fs::File::open(&path)?;
    f.read_to_string(&mut model)?;
    Ok(model.trim_end().to_string())
}

fn read_fwrev(dev_path: &Path) -> Result<String> {
    let mut path = PathBuf::from(dev_path);
    path.push("device");
    path.push("firmware_rev");

    let mut fwrev = String::new();
    trace!("trying {:?}", &path);
    if path.exists() {
        let mut f = fs::File::open(&path)?;
        f.read_to_string(&mut fwrev)?;
    } else {
        path.pop();
        path.push("rev");
        trace!("trying {:?}", &path);
        if path.exists() {
            let mut f = fs::File::open(&path)?;
            f.read_to_string(&mut fwrev)?;
        } else {
            bail!("neither \"firmware_dev\" or \"rev\" is found");
        }
    }
    Ok(fwrev.trim_end().to_string())
}

/// Given a device name, determine its model, firmware version and size.
pub fn devname_to_model_fwrev_size<D: AsRef<OsStr>>(name_in: D) -> Result<(String, String, u64)> {
    let unknown = "<UNKNOWN>";
    let mut dev_path = PathBuf::from("/sys/block");
    dev_path.push(name_in.as_ref());

    let model = match read_model(&dev_path) {
        Ok(v) => v,
        Err(e) => {
            warn!(
                "storage_info: Failed to read model string for {:?} ({:#}), \
                 dm / md devices are not supported",
                &dev_path, &e
            );
            unknown.to_string()
        }
    };

    let fwrev = match read_fwrev(&dev_path) {
        Ok(v) => v,
        Err(e) => {
            warn!(
                "storage_info: Failed to read firmware revision for {:?} ({:#}), \
                 dm / md devices are not supported",
                &dev_path, &e
            );
            unknown.to_string()
        }
    };

    let mut size_path = dev_path.clone();
    size_path.push("size");

    let mut size = String::new();
    let mut f = fs::File::open(&size_path)?;
    f.read_to_string(&mut size)?;
    let size = size.trim().parse::<u64>()? * 512;

    Ok((model, fwrev, size))
}

/// Find all devices hosting swap
pub fn swap_devnames() -> Result<Vec<OsString>> {
    let mut devnames = Vec::new();
    for swap in SwapIter::new()? {
        let swap = swap.context("parse active swap entry")?;
        if swap.kind == "partition" {
            devnames.push(devnr_to_devname(fs::metadata(&swap.source)?.st_rdev())?);
        } else {
            devnames.push(path_to_devname(&swap.source)?);
        }
    }
    Ok(devnames)
}

/// Given a device name, determine whether it's rotational.
pub fn is_devname_rotational<P: AsRef<OsStr>>(devname: P) -> Result<bool> {
    let mut sysblk_path = PathBuf::from("/sys/block");
    sysblk_path.push(devname.as_ref());
    sysblk_path.push("queue");
    sysblk_path.push("rotational");

    let mut buf = String::new();
    fs::File::open(&sysblk_path).and_then(|mut f| f.read_to_string(&mut buf))?;

    trace!("read {:?} content '{}'", &sysblk_path, buf.trim());
    match scan_fmt!(&buf, "{d}", u32) {
        Ok(v) => Ok(v != 0),
        Err(e) => bail!("parse error: '{}' ({:?})", &buf, &e),
    }
}

/// Give a path, determine whether it's backed by a HDD.
pub fn is_path_rotational<P: AsRef<Path>>(path_in: P) -> bool {
    let path = path_in.as_ref();

    let devname = match path_to_devname(path) {
        Ok(v) => v,
        Err(e) => {
            warn!(
                "Failed to determine device name for {:?} ({:?}), assuming SSD",
                path, &e
            );
            return false;
        }
    };

    match is_devname_rotational(&devname) {
        Ok(v) => v,
        Err(e) => {
            warn!(
                "Failed to determine whether {:?} is rotational ({:?}), assuming SSD",
                &path, &e
            );
            false
        }
    }
}

/// Is any of the swaps rotational?
pub fn is_swap_rotational() -> bool {
    match swap_devnames() {
        Ok(devnames) => {
            debug!("swap devices: {:?}", &devnames);
            for devname in devnames {
                match is_devname_rotational(&devname) {
                    Ok(true) => {
                        debug!("swap device {:?} is rotational", &devname);
                        return true;
                    }
                    Ok(false) => debug!("swap device {:?} is not rotational", &devname),
                    Err(e) => warn!(
                        "Failed to determine whether {:?} is rotational ({:?})",
                        &devname, &e
                    ),
                }
            }
        }
        Err(e) => warn!("Failed to determine swap devices ({:?}), assuming SSD", &e),
    }
    false
}

#[cfg(test)]
mod tests {
    use std::env;

    #[test]
    fn test() {
        let _ = ::env_logger::try_init();
        if let Ok(v) = env::var("ROTATIONAL_TARGET") {
            println!("{} rotational={}", &v, super::is_path_rotational(&v));
        }
        println!("CWD rotational={}", super::is_path_rotational("."));
        println!("swap rotational={}", super::is_swap_rotational());
    }
}


#[cfg(test)]
mod source_resolution_tests {
    use super::*;

    #[test]
    fn uses_unambiguous_nofsroot_json_lookup() {
        assert_eq!(FINDMNT_SOURCE_ARGS, ["--json", "--first-only", "--evaluate",
                   "--nofsroot", "--output", "SOURCE", "--target"]);
    }

    #[test]
    fn resolves_nvme_emmc_and_usb_device_paths() {
        for name in ["/dev/nvme0n1p6", "/dev/mmcblk0p2", "/dev/sda1"] {
            let json = serde_json::json!({"filesystems": [{"source": name}]}).to_string();
            assert_eq!(findmnt_source(json.as_bytes()).unwrap(), PathBuf::from(name));
        }
    }

    #[test]
    fn preserves_spaces_and_brackets_in_real_device_names() {
        // --nofsroot removes the filesystem suffix, NOT characters in a real name.
        let json = br#"{"filesystems":[{"source":"/dev/mapper/disk [data]"}]}"#;
        assert_eq!(findmnt_source(json).unwrap(), PathBuf::from("/dev/mapper/disk [data]"));
    }

    #[test]
    fn rejects_no_filesystem() {
        assert!(findmnt_source(br#"{"filesystems":[]}"#).is_err());
    }

    #[test]
    fn rejects_multiple_filesystems() {
        assert!(findmnt_source(br#"{"filesystems":[{"source":"/dev/a"},{"source":"/dev/b"}]}"#).is_err());
    }

    #[test]
    fn rejects_nonblock_pseudo_source() {
        for name in ["overlay", "tmpfs", "host:/export", "", "relative", "/tmp/file", "/device/x"] {
            let json = serde_json::json!({"filesystems": [{"source": name}]}).to_string();
            assert!(findmnt_source(json.as_bytes()).is_err());
        }
    }

    #[test]
    fn rejects_invalid_or_missing_json_source() {
        for value in [b"not JSON".as_ref(), br#"{}"#.as_ref(), br#"{"filesystems":[{}]}"#.as_ref(),
                      br#"{"filesystems":[{"source":null}]}"#.as_ref()] {
            assert!(findmnt_source(value).is_err());
        }
    }

    #[test]
    fn rejects_embedded_nul() {
        assert!(findmnt_source(br#"{"filesystems":[{"source":"/dev/bad\u0000name"}]}"#).is_err());
    }
}
