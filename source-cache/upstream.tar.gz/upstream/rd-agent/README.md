
# Resource-control demo agent

`rd-agent` orchestrates resource control demo and benchmark scenarios
end-to-end. It runs benchmarks to establish the baseline, manages `rd-hashd`
instances as the primary workloads, simulates resource conflicts with other
workloads, and monitors the system and workloads to generate detailed
reports.

Comprehensive resource control requires a number of components closely
working together. `rd-agent` will check all the needed features and try to
configure the system as necessary, and report all the missing pieces. The
following basic system configuration is expected.

* The root filesystem must be btrfs and on a physical device (not md or dm).

* Swap must be on the same device as root filesystem larger than half the
  memory. Swapfile on the root filesystem is preferred.

* The scratch directory must be on the root filesystem.

* `systemd` is the system agent and using cgroup2.

Some of the system configuration failures can be ignored with `--force`.
However, resource isolation may not work as expected.

Configurations, commanding and reporting happen through json files under
`/var/lib/resctl-demo` by default. All files used by workloads are under the
`scratch` sub-directory. Take a look at `index.json` and `cmd.json` if you
want to explore the control files.

`rd-agent` is usually used as a part of `resctl-demo` or `resctl-bench`. For
more information on the containing projects, visit:

  https://github.com/facebookexperimental/resctl-demo


## Embedded support-file compatibility (reviewed downstream repair)

This source revision embeds a Python 3 IO-latency collector with the BCC
C language options required for the anonymous tagged structure members used
by newer Linux headers. The measurement program itself is unchanged. Generated
helpers are reconciled with the current executable, including after the
`--reset` performed by `resctl-bench`; do not maintain fixes only in an emitted
`misc-bin/` directory, because reset removes those files.

For file-only inspection of the actual executable, as an ordinary user:

```sh
rd-agent --export-support /existing/parent/new-helper-directory
```

The destination must not already exist and the option must be used alone.
This path only exports the four embedded support files. It does not construct
normal agent configuration, access a disk, run systemd, change swap, attach BPF,
or run a workload. Normal agent execution still checks the actual BPF collector;
the export path is not a bypass for benchmark requirements.

`misc::support_tests` includes reset/recreation, stale-file, exact-byte and
symlink regressions. See the containing build kit's `docs/NATIVE-REPAIR.md` for
the source patch, compatibility contract and mandatory packaging checks.
