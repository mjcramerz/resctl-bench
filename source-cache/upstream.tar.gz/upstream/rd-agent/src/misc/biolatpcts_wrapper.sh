#!/bin/sh
# Copyright (c) Facebook, Inc. and its affiliates
# IOCost Lab: use the checked Debian interpreter and local compatibility helper.
# No global Python/BCC/kernel files or vendor binaries are changed.
exec /usr/bin/python3 -I -B "$(dirname "$0")/biolatpcts.py" "$@"
