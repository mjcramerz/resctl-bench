#!/usr/bin/python3
# SPDX-License-Identifier: GPL-2.0
# Copyright (c) Facebook, Inc. and its affiliates.
"""Exact, native-owned, non-swappable memory balloon for resctl calibration.

The caller supplies a byte count. We round UP to the host page size, fault every
page, and only then send READY=1. Never shrink, restart, or report partial success:
changing the held memory invalidates the native calibration's arithmetic.

systemd owns process lifetime and enforces MemorySwapMax=0. No third-party modules,
children, global sysctl writes, cache drops, or workload modification are used.
"""
from __future__ import annotations

import argparse
import json
import mmap
import os
from pathlib import Path
import re
import signal
import socket
import sys
import tempfile
import time

MIB = 1024 * 1024
START_TIMEOUT = 12.0  # below rd-util's default 15-second systemd start deadline
CHUNK = 16 * MIB


class BalloonError(RuntimeError):
    pass


class Stopped(Exception):
    pass


def rounded_size(value: str, page: int) -> int:
    if not re.fullmatch(r'[0-9]+', value) or len(value) > 20:
        raise BalloonError('BYTES must be a non-negative decimal integer')
    if page <= 0 or page & (page - 1):
        raise BalloonError('invalid operating-system page size')
    size = int(value)
    if size > sys.maxsize - page + 1:
        raise BalloonError('BYTES exceeds the address-space integer limit')
    return ((size + page - 1) // page) * page


def memory_info(path: Path = Path('/proc/meminfo')) -> dict[str, int]:
    values = {}
    for line in path.read_text().splitlines():
        parts = line.split()
        if parts and parts[0] in ('MemTotal:', 'MemAvailable:'):
            if len(parts) != 3 or parts[2] != 'kB' or not parts[1].isdigit():
                raise BalloonError('invalid physical-memory counters')
            key = parts[0][:-1]
            if key in values:
                raise BalloonError('duplicate physical-memory counter')
            values[key] = int(parts[1]) * 1024
    if not 0 <= values.get('MemAvailable', -1) <= values.get('MemTotal', -2):
        raise BalloonError('missing/inconsistent physical-memory counters')
    if values['MemTotal'] <= 0:
        raise BalloonError('invalid physical-memory size')
    return values


def oom_count(path: Path = Path('/proc/vmstat')) -> int:
    for line in path.read_text().splitlines():
        fields = line.split()
        if fields and fields[0] == 'oom_kill':
            if len(fields) != 2 or not fields[1].isdigit():
                break
            return int(fields[1])
    raise BalloonError('cannot read the kernel OOM counter')


def notify(message: str, address: str | None = None) -> None:
    address = os.environ.get('NOTIFY_SOCKET') if address is None else address
    if not address or address[0] not in ('/', '@'):
        raise BalloonError('an absolute or abstract systemd NOTIFY_SOCKET is required')
    if address.startswith('@'):
        address = '\0' + address[1:]
    with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as channel:
        channel.connect(address)
        channel.sendall(message.encode('utf-8'))


def write_status(path: Path | None, **fields) -> None:
    if path is None:
        return
    # The native owner passes a file within its pre-created work directory.
    # Atomic replace never follows an existing leaf symlink or truncates a link.
    if (not path.is_absolute() or '..' in path.parts or not path.parent.is_dir()
            or any(parent.is_symlink() for parent in path.parents)):
        raise BalloonError('status must be in an existing absolute work directory')
    row = {'schema': 1, 'pid': os.getpid(), 'epoch': time.time(),
           'monotonic': time.monotonic(), **fields}
    fd, temporary = tempfile.mkstemp(prefix='.balloon-status-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(row, stream, sort_keys=True)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def allocate_exact(size: int, page: int, deadline: float, initial_oom: int,
                   *, read_memory=memory_info, read_oom=oom_count,
                   clock=time.monotonic, sleep=time.sleep):
    """Fault a real private mapping; clean it up on EVERY incomplete start.

    MemAvailable is only an allocation admission signal, not a safety proof.
    OOM monitoring is independent, and the agent monitors the service after READY.
    A small reserve prevents this helper from intentionally consuming the last
    reported available pages. Exhaustion fails the start; it never changes size.
    """
    info = read_memory()
    reserve = max(128 * MIB, info['MemTotal'] // 64)
    if size > max(0, info['MemTotal'] - reserve):
        raise BalloonError('requested balloon exceeds physical RAM minus emergency reserve')
    if size == 0:
        return None
    mapping = mmap.mmap(-1, size, flags=mmap.MAP_PRIVATE | mmap.MAP_ANONYMOUS,
                        prot=mmap.PROT_READ | mmap.PROT_WRITE)
    try:
        # Avoid huge-page allocation/compaction surprises; this is a base-page
        # accounting workload, not a THP benchmark. MADV_NOHUGEPAGE is Linux-only.
        if hasattr(mmap, 'MADV_NOHUGEPAGE'):
            mapping.madvise(mmap.MADV_NOHUGEPAGE)
        for start in range(0, size, max(page, CHUNK // page * page)):
            end = min(size, start + max(page, CHUNK // page * page))
            while True:
                if read_oom() != initial_oom:
                    raise BalloonError('kernel OOM counter changed while inflating balloon')
                if clock() >= deadline:
                    raise BalloonError('exact balloon allocation timed out; no READY sent')
                if read_memory()['MemAvailable'] >= end - start + reserve:
                    break
                sleep(0.05)
            for offset in range(start, end, page):
                mapping[offset] = 1
        if read_oom() != initial_oom:
            raise BalloonError('kernel OOM counter changed while inflating balloon')
        if clock() >= deadline:
            raise BalloonError('exact balloon allocation exceeded startup deadline')
        return mapping
    except BaseException:
        mapping.close()
        raise


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('bytes', metavar='BYTES')
    parser.add_argument('--status', type=Path, help='native work-directory status file')
    args = parser.parse_args(argv)
    held = None
    ready = False
    size = 0

    def stop(_signum, _frame):
        raise Stopped()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    try:
        if os.environ.get('IOCOST_BALLOON_STATE_DIR'):
            raise BalloonError('legacy IOCost balloon override detected; restore the old session first')
        size = rounded_size(args.bytes, os.sysconf('SC_PAGE_SIZE'))
        # Validate notification transport BEFORE allocating potentially large RAM.
        notify('STATUS=Allocating exact native balloon')
        write_status(args.status, state='allocating', requested_bytes=int(args.bytes), held_bytes=0,
                     rounded_bytes=size)
        held = allocate_exact(size, os.sysconf('SC_PAGE_SIZE'),
                              time.monotonic() + START_TIMEOUT, oom_count())
        write_status(args.status, state='ready', requested_bytes=int(args.bytes),
                     rounded_bytes=size, held_bytes=size)
        notify('READY=1\nSTATUS=Holding exactly %d bytes' % size)
        ready = True
        # No adaptive changes or automatic restart. The native agent supervises
        # liveness; SIGTERM releases the mapping during a native resize/teardown.
        while True:
            signal.pause()
    except Stopped:
        return 0 if ready else 1
    except (BalloonError, OSError, ValueError, OverflowError, MemoryError) as exc:
        print('balloon: ' + str(exc), file=sys.stderr, flush=True)
        return 1
    finally:
        # Ignore further termination signals so release/status cleanup completes.
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        if held is not None:
            held.close()
        try:
            write_status(args.status, state='stopped', requested_bytes=int(args.bytes) if re.fullmatch(r'[0-9]{1,20}', args.bytes) else None,
                         rounded_bytes=size, held_bytes=0, was_ready=ready)
        except (OSError, BalloonError, MemoryError) as exc:
            print('balloon: cannot publish stopped status: ' + str(exc), file=sys.stderr)


if __name__ == '__main__':
    sys.exit(main())
