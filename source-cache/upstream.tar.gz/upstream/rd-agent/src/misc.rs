// Copyright (c) Facebook, Inc. and its affiliates.
use super::Config;
use anyhow::{anyhow, bail, Context, Result};
use std::ffi::OsString;
use std::fs::{self, DirBuilder, OpenOptions};
use std::io::Write;
use std::os::unix::fs::{DirBuilderExt, OpenOptionsExt, PermissionsExt};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::process::Command;

use rd_util::*;

// bcc randomly fails to start occassionally. Give it several tries before
// giving up.
pub const BCC_RETRIES: u32 = 2;

const MISC_BINS: [(&str, &[u8]); 5] = [
    ("memory-balloon.py", include_bytes!("misc/memory-balloon.py")),
    (
        "iocost_coef_gen.py",
        include_bytes!("misc/iocost_coef_gen.py"),
    ),
    ("sideloader.py", include_bytes!("misc/sideloader.py")),
    ("biolatpcts.py", include_bytes!("misc/biolatpcts.py")),
    (
        "biolatpcts_wrapper.sh",
        include_bytes!("misc/biolatpcts_wrapper.sh"),
    ),
];

// These are generated runtime assets, not administrator configuration. Reconcile
// them with THIS executable on every startup, including non-reset upgrades.
// Never follow a generated-file symlink or truncate an existing helper in place.
fn write_misc_bins(directory: &Path) -> Result<()> {
    write_embedded_bins(directory, &MISC_BINS)
}

pub(crate) fn write_embedded_bins(directory: &Path, bins: &[(&str, &[u8])]) -> Result<()> {
    let meta = fs::symlink_metadata(directory)?;
    if !meta.is_dir() || meta.file_type().is_symlink() {
        bail!("misc support directory must be a real directory: {:?}", directory);
    }
    static NEXT_TMP: AtomicU64 = AtomicU64::new(0);
    for (name, body) in bins {
        let path = directory.join(name);
        match fs::symlink_metadata(&path) {
            Ok(meta) => {
                if !meta.file_type().is_file() {
                    bail!("refusing non-regular generated support file: {:?}", path);
                }
                // Even a matching file is replaced if its mode is not exact.
                // Atomic rename avoids changing permissions of any hardlink.
                if meta.permissions().mode() & 0o7777 == 0o755 && fs::read(&path)?.as_slice() == *body {
                    continue;
                }
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
            Err(e) => return Err(e.into()),
        }
        let temporary = directory.join(format!(
            ".{}.{}-{}.tmp", name, std::process::id(),
            NEXT_TMP.fetch_add(1, Ordering::Relaxed)
        ));
        let mut file = OpenOptions::new().write(true).create_new(true).mode(0o600)
            .open(&temporary).with_context(|| format!("create {:?}", temporary))?;
        let result = (|| -> Result<()> {
            file.write_all(body)?;
            file.set_permissions(fs::Permissions::from_mode(0o755))?;
            file.sync_all()?;
            fs::rename(&temporary, &path)?;
            Ok(())
        })();
        if result.is_err() {
            let _ = fs::remove_file(&temporary);
        }
        result.with_context(|| format!("materialize embedded helper {:?}", path))?;
    }
    Ok(())
}

// File-only introspection, deliberately BEFORE Config, systemd, storage lookup,
// umask changes or normal argument-file processing. An exclusive new directory
// is required. This is not a benchmark, a BPF probe or a startup-check bypass.
fn parse_export_request(args: &[OsString]) -> Option<Result<PathBuf>> {
    let present = args.iter().any(|s| s == "--export-support" ||
        s.to_str().map_or(false, |s| s.starts_with("--export-support=")));
    if !present {
        return None;
    }
    let path = if args.len() == 2 && args[0] == "--export-support" {
        Some(PathBuf::from(&args[1]))
    } else if args.len() == 1 {
        args[0].to_str().and_then(|s| s.strip_prefix("--export-support="))
            .map(PathBuf::from)
    } else {
        None
    };
    Some(path.filter(|p| !p.as_os_str().is_empty()).ok_or_else(|| anyhow!(
        "Usage: rd-agent --export-support NEW_DIRECTORY (no other options)"
    )))
}

pub fn maybe_export_support(args: &[OsString]) -> Option<Result<()>> {
    parse_export_request(args).map(|result| {
        let directory = result?;
        DirBuilder::new().mode(0o700).create(&directory)
            .with_context(|| format!("export requires a new directory: {:?}", directory))?;
        write_misc_bins(&directory)
    })
}

pub fn prepare_misc_bins(cfg: &Config, prepare_only: bool) -> Result<()> {
    write_misc_bins(Path::new(&cfg.misc_bin_path))?;

    if !prepare_only && cfg.biolatpcts_bin.is_some() {
        let mut retries = BCC_RETRIES;
        loop {
            match run_command(
                Command::new(cfg.biolatpcts_bin.as_ref().unwrap())
                    .arg(format!("{}:{}", cfg.scr_devnr.0, cfg.scr_devnr.1))
                    .args(&["-i", "0"]),
                "is bcc working? https://github.com/iovisor/bcc",
            ) {
                Ok(()) => break,
                Err(e) if retries == 0 => return Err(e),
                Err(_) => retries -= 1,
            }
        }
    }

    Ok(())
}

#[cfg(test)]
mod support_tests {
    use super::*;
    use std::os::unix::fs::symlink;

    struct TestDirectory(PathBuf);
    impl TestDirectory {
        fn new() -> Self {
            static NEXT: AtomicU64 = AtomicU64::new(0);
            let path = std::env::temp_dir().join(format!(
                "rd-agent-support-test-{}-{}", std::process::id(),
                NEXT.fetch_add(1, Ordering::Relaxed)
            ));
            fs::create_dir(&path).unwrap();
            Self(path)
        }
    }
    impl Drop for TestDirectory {
        fn drop(&mut self) { let _ = fs::remove_dir_all(&self.0); }
    }

    #[test]
    fn exports_exact_embedded_bytes() {
        let dir = TestDirectory::new();
        write_misc_bins(&dir.0).unwrap();
        assert_eq!(fs::read_dir(&dir.0).unwrap().count(), MISC_BINS.len());
        for (name, body) in &MISC_BINS {
            let file = dir.0.join(name);
            assert_eq!(fs::read(&file).unwrap().as_slice(), *body);
            assert_eq!(fs::metadata(file).unwrap().permissions().mode() & 0o777, 0o755);
        }
    }

    #[test]
    fn reset_recreation_preserves_compatibility() {
        let dir = TestDirectory::new();
        write_misc_bins(&dir.0).unwrap();
        // This is the exact helper-file removal performed by reset_agent_states.
        for (name, _) in &MISC_BINS { fs::remove_file(dir.0.join(name)).unwrap(); }
        write_misc_bins(&dir.0).unwrap();
        let text = fs::read_to_string(dir.0.join("biolatpcts.py")).unwrap();
        assert!(text.starts_with("#!/usr/bin/python3\n"));
        assert!(text.contains("cflags=[\"-fms-extensions\", \"-Wno-microsoft-anon-tag\"]"));
        assert!(text.contains("RAW_TRACEPOINT_PROBE(block_rq_complete)"));
    }

    #[test]
    fn upgrades_stale_helpers_without_reset() {
        let dir = TestDirectory::new();
        fs::write(dir.0.join("biolatpcts.py"), "obsolete helper\n").unwrap();
        write_misc_bins(&dir.0).unwrap();
        assert!(fs::read_to_string(dir.0.join("biolatpcts.py")).unwrap().contains("-fms-extensions"));
    }

    #[test]
    fn fixes_non_executable_mode_without_mutating_hardlink() {
        let dir = TestDirectory::new();
        let (_, body) = MISC_BINS.iter().find(|(name, _)| *name == "biolatpcts.py").unwrap();
        let external = dir.0.join("external");
        fs::write(&external, body).unwrap();
        fs::set_permissions(&external, fs::Permissions::from_mode(0o600)).unwrap();
        fs::hard_link(&external, dir.0.join("biolatpcts.py")).unwrap();
        write_misc_bins(&dir.0).unwrap();
        assert_eq!(fs::metadata(external).unwrap().permissions().mode() & 0o777, 0o600);
        assert_eq!(fs::metadata(dir.0.join("biolatpcts.py")).unwrap().permissions().mode() & 0o777, 0o755);
    }

    #[test]
    fn rejects_helper_symlink_without_touching_target() {
        let dir = TestDirectory::new();
        let external = dir.0.join("external");
        fs::write(&external, "do not overwrite").unwrap();
        symlink(&external, dir.0.join("biolatpcts.py")).unwrap();
        assert!(write_misc_bins(&dir.0).is_err());
        assert_eq!(fs::read_to_string(external).unwrap(), "do not overwrite");
    }

    #[test]
    fn rejects_directory_symlink() {
        let dir = TestDirectory::new();
        symlink(&dir.0, dir.0.join("linked")).unwrap();
        assert!(write_misc_bins(&dir.0.join("linked")).is_err());
    }

    #[test]
    fn export_mode_requires_new_directory() {
        let dir = TestDirectory::new();
        let args = vec![OsString::from("--export-support"), dir.0.clone().into_os_string()];
        assert!(maybe_export_support(&args).unwrap().is_err());
        assert_eq!(fs::read_dir(&dir.0).unwrap().count(), 0);
    }

    #[test]
    fn export_mode_creates_only_requested_helpers() {
        let dir = TestDirectory::new();
        let path = dir.0.join("export");
        let args = vec![OsString::from("--export-support"), path.clone().into_os_string()];
        maybe_export_support(&args).unwrap().unwrap();
        assert_eq!(fs::read_dir(path).unwrap().count(), MISC_BINS.len());
    }

    #[test]
    fn refuses_export_combined_with_benchmark_options() {
        for args in [vec!["--export-support"], vec!["--export-support", "/tmp/x", "--reset"],
                     vec!["--prepare", "--export-support", "/tmp/x"], vec!["--export-support="],
                     vec!["--export-support=", "--reset"]] {
            let args: Vec<_> = args.into_iter().map(OsString::from).collect();
            assert!(parse_export_request(&args).unwrap().is_err());
        }
    }

    #[test]
    fn normal_options_do_not_enter_export_mode() {
        assert!(parse_export_request(&[OsString::from("--help")]).is_none());
        assert!(parse_export_request(&[]).is_none());
        let path = parse_export_request(&[OsString::from("--export-support=/tmp/new")]).unwrap().unwrap();
        assert_eq!(path, PathBuf::from("/tmp/new"));
    }
}
